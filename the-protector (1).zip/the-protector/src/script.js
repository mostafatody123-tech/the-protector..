const VAULT_KEY = "protector_cloud_info_v1";
const memoryStore = {};

function readStore(key) {
    try {
        if (window.localStorage) {
            const raw = window.localStorage.getItem(key);
            if (raw !== null) return raw;
        }
    } catch (e) {}
    return Object.prototype.hasOwnProperty.call(memoryStore, key) ? memoryStore[key] : null;
}

function writeStore(key, value) {
    memoryStore[key] = value;
    try {
        if (window.localStorage) {
            window.localStorage.setItem(key, value);
            return true;
        }
    } catch (e) {}
    return false;
}

function getLocalEntries() {
    try {
        const raw = readStore(VAULT_KEY);
        const parsed = raw ? JSON.parse(raw) : [];
        return Array.isArray(parsed) ? parsed : [];
    } catch (e) {
        return [];
    }
}

function setLocalEntries(list) {
    writeStore(VAULT_KEY, JSON.stringify(list));
}

function handleOtpInput(val) {
    const clean = val.trim();
    if (clean.length >= 4 && navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(clean).catch(() => {});
    }
}

function createPassword() {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%^&*";
    let result = "";
    for (let i = 0; i < 14; i++) {
        result += chars[Math.floor(Math.random() * chars.length)];
    }
    document.getElementById("generatedPass").value = result;
}

function applyGeneratedPassword() {
    const gen = document.getElementById("generatedPass").value;
    if (!gen) return;
    document.getElementById("accountSecret").value = gen;
}

function saveInfoEntry() {
    const service = document.getElementById("accountService").value.trim();
    const identifier = document.getElementById("accountIdentifier").value.trim();
    const secret = document.getElementById("accountSecret").value.trim();
    const saveStatus = document.getElementById("saveStatus");

    if (!service || !secret) {
        saveStatus.style.color = "#f87171";
        saveStatus.textContent = "أدخل اسم الموقع/التطبيق وكلمة السر أو المعلومة.";
        return;
    }

    const list = getLocalEntries();
    list.unshift({
        id: Date.now(),
        service,
        identifier,
        secret
    });
    setLocalEntries(list);

    document.getElementById("accountService").value = "";
    document.getElementById("accountIdentifier").value = "";
    document.getElementById("accountSecret").value = "";
    document.getElementById("generatedPass").value = "";

    saveStatus.style.color = "#34d399";
    saveStatus.textContent = "تم حفظ المعلومات بنجاح.";
    setTimeout(() => { saveStatus.textContent = ""; }, 2500);

    renderEntries();
}

function copySecret(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).catch(() => {});
    }
}

function deleteEntry(id) {
    const filtered = getLocalEntries().filter((item) => String(item.id) !== String(id));
    setLocalEntries(filtered);
    renderEntries();
}

function escapeHtml(str) {
    return String(str || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}

function renderEntries() {
    const container = document.getElementById("entriesContainer");
    const query = (document.getElementById("searchVault").value || "").trim().toLowerCase();
    let list = getLocalEntries();

    if (query) {
        list = list.filter((item) =>
            item.service.toLowerCase().includes(query) ||
            (item.identifier && item.identifier.toLowerCase().includes(query))
        );
    }

    if (!list.length) {
        container.innerHTML = '<p class="empty-state">لا توجد معلومات محفوظة بعد.</p>';
        return;
    }

    container.innerHTML = list.map((item) => `
        <div class="vault-item">
            <div class="vault-site">${escapeHtml(item.service)}</div>
            ${item.identifier ? `<div class="vault-user">الحساب: ${escapeHtml(item.identifier)}</div>` : ""}
            <div class="vault-pass">كلمة السر: ${escapeHtml(item.secret)}</div>
            <div class="vault-actions">
                <button onclick="copySecret(${JSON.stringify(item.secret)})">نسخ كلمة السر</button>
                <button class="btn-danger" onclick="deleteEntry(${JSON.stringify(item.id)})">حذف</button>
            </div>
        </div>
    `).join("");
}

document.addEventListener("DOMContentLoaded", renderEntries);
renderEntries();
